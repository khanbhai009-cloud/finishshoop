
'use client';

import { useState, useEffect } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { useRouter } from 'next/navigation';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { Product, User, ClickTracking } from '../../lib/types';
import Header from '../../components/Header';

export default function AdminPanel() {
  const [user, loading] = useAuthState(auth);
  const [activeTab, setActiveTab] = useState('products');
  const [products, setProducts] = useState<Product[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [clicks, setClicks] = useState<ClickTracking[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const router = useRouter();

  // Form states
  const [formData, setFormData] = useState({
    name: '',
    imageUrl: '',
    price: '',
    discount: '',
    description: '',
    affiliateLink: '',
    tag: ''
  });
  const [editingProduct, setEditingProduct] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && (!user || user.email !== 'admin@gmail.com')) {
      router.push('/');
    }
  }, [user, loading, router]);

  useEffect(() => {
    if (user && user.email === 'admin@gmail.com') {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    try {
      await Promise.all([
        fetchProducts(),
        fetchUsers(),
        fetchClicks()
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchProducts = async () => {
    const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    const data = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date()
    })) as Product[];
    setProducts(data);
  };

  const fetchUsers = async () => {
    const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    const data = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate() || new Date()
    })) as User[];
    setUsers(data);
  };

  const fetchClicks = async () => {
    const q = query(collection(db, 'clickTracking'), orderBy('clickedAt', 'desc'));
    const snapshot = await getDocs(q);
    const data = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      clickedAt: doc.data().clickedAt?.toDate() || new Date()
    })) as ClickTracking[];
    setClicks(data);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const productData = {
        name: formData.name,
        imageUrl: formData.imageUrl,
        price: parseFloat(formData.price),
        discount: parseFloat(formData.discount) || 0,
        description: formData.description,
        affiliateLink: formData.affiliateLink,
        tag: formData.tag,
        clicks: 0,
        createdAt: new Date()
      };

      if (editingProduct) {
        await updateDoc(doc(db, 'products', editingProduct), productData);
      } else {
        await addDoc(collection(db, 'products'), productData);
      }

      setFormData({ name: '', imageUrl: '', price: '', discount: '', description: '', affiliateLink: '', tag: '' });
      setEditingProduct(null);
      setShowAddProduct(false);
      fetchProducts();
    } catch (error) {
      console.error('Error saving product:', error);
    }
  };

  const handleEdit = (product: Product) => {
    setFormData({
      name: product.name,
      imageUrl: product.imageUrl,
      price: product.price.toString(),
      discount: product.discount.toString(),
      description: product.description,
      affiliateLink: product.affiliateLink,
      tag: product.tag
    });
    setEditingProduct(product.id);
    setShowAddProduct(true);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      try {
        await deleteDoc(doc(db, 'products', id));
        fetchProducts();
      } catch (error) {
        console.error('Error deleting product:', error);
      }
    }
  };

  if (loading || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <i className="ri-loader-4-line animate-spin text-4xl text-blue-600 mb-4 w-16 h-16 flex items-center justify-center mx-auto"></i>
            <p className="text-gray-600">Loading admin panel...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!user || user.email !== 'admin@gmail.com') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Admin Header */}
        <div className="bg-blue-600 text-white rounded-lg p-6 mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Panel</h1>
          <p className="text-blue-100">Manage products, users, and analytics</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <i className="ri-shopping-bag-line text-3xl text-blue-600 w-12 h-12 flex items-center justify-center"></i>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{products.length}</p>
                <p className="text-gray-600">Products</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <i className="ri-user-line text-3xl text-green-600 w-12 h-12 flex items-center justify-center"></i>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{users.length}</p>
                <p className="text-gray-600">Users</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <i className="ri-mouse-line text-3xl text-purple-600 w-12 h-12 flex items-center justify-center"></i>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{clicks.length}</p>
                <p className="text-gray-600">Total Clicks</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <i className="ri-line-chart-line text-3xl text-orange-600 w-12 h-12 flex items-center justify-center"></i>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{products.reduce((sum, p) => sum + (p.clicks || 0), 0)}</p>
                <p className="text-gray-600">Product Views</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex">
              <button
                onClick={() => setActiveTab('products')}
                className={`py-4 px-6 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                  activeTab === 'products' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Products Management
              </button>
              <button
                onClick={() => setActiveTab('users')}
                className={`py-4 px-6 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                  activeTab === 'users' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Users ({users.length})
              </button>
              <button
                onClick={() => setActiveTab('analytics')}
                className={`py-4 px-6 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                  activeTab === 'analytics' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                Click Analytics
              </button>
            </nav>
          </div>

          <div className="p-6">
            {/* Products Tab */}
            {activeTab === 'products' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-lg font-semibold">Products Management</h2>
                  <button
                    onClick={() => {
                      setShowAddProduct(true);
                      setEditingProduct(null);
                      setFormData({ name: '', imageUrl: '', price: '', discount: '', description: '', affiliateLink: '', tag: '' });
                    }}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 whitespace-nowrap cursor-pointer"
                  >
                    <i className="ri-add-line mr-2 w-4 h-4 flex items-center justify-center inline-flex"></i>
                    Add Product
                  </button>
                </div>

                {showAddProduct && (
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <h3 className="text-lg font-medium mb-4">
                      {editingProduct ? 'Edit Product' : 'Add New Product'}
                    </h3>
                    <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <input
                        type="text"
                        placeholder="Product Name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-2 text-sm"
                        required
                      />
                      <input
                        type="url"
                        placeholder="Image URL"
                        value={formData.imageUrl}
                        onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-2 text-sm"
                        required
                      />
                      <input
                        type="number"
                        step="0.01"
                        placeholder="Price"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-2 text-sm"
                        required
                      />
                      <input
                        type="number"
                        placeholder="Discount %"
                        value={formData.discount}
                        onChange={(e) => setFormData({ ...formData, discount: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-2 text-sm"
                      />
                      <select
                        value={formData.tag}
                        onChange={(e) => setFormData({ ...formData, tag: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-2 text-sm pr-8"
                      >
                        <option value="">No Tag</option>
                        <option value="New">New</option>
                        <option value="Best Seller">Best Seller</option>
                        <option value="Sale">Sale</option>
                      </select>
                      <input
                        type="url"
                        placeholder="Affiliate Link"
                        value={formData.affiliateLink}
                        onChange={(e) => setFormData({ ...formData, affiliateLink: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-2 text-sm"
                        required
                      />
                      <textarea
                        placeholder="Description"
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        className="border border-gray-300 rounded-md px-3 py-2 text-sm md:col-span-2"
                        rows={3}
                        required
                      ></textarea>
                      <div className="md:col-span-2 flex space-x-2">
                        <button
                          type="submit"
                          className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 whitespace-nowrap cursor-pointer"
                        >
                          {editingProduct ? 'Update Product' : 'Add Product'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowAddProduct(false);
                            setEditingProduct(null);
                          }}
                          className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 whitespace-nowrap cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  </div>
                )}

                <div className="grid grid-cols-1 gap-4">
                  {products.map((product) => (
                    <div key={product.id} className="border border-gray-200 rounded-lg p-4 flex items-center space-x-4">
                      <img src={product.imageUrl} alt={product.name} className="w-16 h-16 object-cover rounded" />
                      <div className="flex-1">
                        <h3 className="font-medium">{product.name}</h3>
                        <p className="text-sm text-gray-600">${product.price} • {product.clicks || 0} clicks</p>
                        {product.tag && (
                          <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mt-1">
                            {product.tag}
                          </span>
                        )}
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleEdit(product)}
                          className="text-blue-600 hover:text-blue-800 cursor-pointer"
                        >
                          <i className="ri-edit-line w-5 h-5 flex items-center justify-center"></i>
                        </button>
                        <button
                          onClick={() => handleDelete(product.id)}
                          className="text-red-600 hover:text-red-800 cursor-pointer"
                        >
                          <i className="ri-delete-bin-line w-5 h-5 flex items-center justify-center"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Users Tab */}
            {activeTab === 'users' && (
              <div>
                <h2 className="text-lg font-semibold mb-6">Registered Users</h2>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Joined</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Clicks</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {users.map((user) => (
                        <tr key={user.uid}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{user.email}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {user.createdAt?.toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {clicks.filter(c => c.userId === user.uid).length}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Analytics Tab */}
            {activeTab === 'analytics' && (
              <div>
                <h2 className="text-lg font-semibold mb-6">Click Analytics</h2>
                <div className="space-y-4">
                  {clicks.map((click) => (
                    <div key={click.id} className="bg-gray-50 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium text-gray-900">{click.productName}</h3>
                          <p className="text-sm text-gray-600">User: {click.userEmail}</p>
                        </div>
                        <div className="text-right text-sm text-gray-500">
                          <div>{click.clickedAt.toLocaleDateString()}</div>
                          <div>{click.clickedAt.toLocaleTimeString()}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                  {clicks.length === 0 && (
                    <div className="text-center py-12">
                      <i className="ri-bar-chart-line text-6xl text-gray-300 mb-4 w-24 h-24 flex items-center justify-center mx-auto"></i>
                      <p className="text-gray-600">No clicks recorded yet</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
