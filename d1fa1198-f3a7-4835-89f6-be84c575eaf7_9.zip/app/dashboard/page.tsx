
'use client';

import { useState, useEffect } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { useRouter } from 'next/navigation';
import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { Product, ClickTracking } from '../../lib/types';
import Header from '../../components/Header';
import ProductCard from '../../components/ProductCard';

export default function Dashboard() {
  const [user, loading, error] = useAuthState(auth);
  const [products, setProducts] = useState<Product[]>([]);
  const [clickHistory, setClickHistory] = useState<ClickTracking[]>([]);
  const [activeTab, setActiveTab] = useState('products');
  const [productsLoading, setProductsLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push('/auth/signin');
    }
  }, [user, loading, router]);

  useEffect(() => {
    if (user) {
      fetchProducts();
      fetchClickHistory();
    }
  }, [user]);

  const fetchProducts = async () => {
    try {
      const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      const productsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date()
      })) as Product[];
      setProducts(productsData);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setProductsLoading(false);
    }
  };

  const fetchClickHistory = async () => {
    if (!user) return;
    
    try {
      const q = query(
        collection(db, 'clickTracking'),
        where('userId', '==', user.uid),
        orderBy('clickedAt', 'desc')
      );
      const querySnapshot = await getDocs(q);
      const clicksData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        clickedAt: doc.data().clickedAt?.toDate() || new Date()
      })) as ClickTracking[];
      setClickHistory(clicksData);
    } catch (error) {
      console.error('Error fetching click history:', error);
    }
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <i className="ri-loader-4-line animate-spin text-4xl text-blue-600 mb-4 w-16 h-16 flex items-center justify-center mx-auto"></i>
            <p className="text-gray-600">Loading dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Welcome back!</h1>
              <p className="text-gray-600 mt-1">{user.email}</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-blue-600">{clickHistory.length}</div>
              <div className="text-sm text-gray-500">Total Clicks</div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex">
              <button
                onClick={() => setActiveTab('products')}
                className={`py-4 px-6 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                  activeTab === 'products'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <i className="ri-shopping-bag-line mr-2 w-4 h-4 flex items-center justify-center inline-flex"></i>
                Browse Products
              </button>
              <button
                onClick={() => setActiveTab('history')}
                className={`py-4 px-6 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                  activeTab === 'history'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <i className="ri-history-line mr-2 w-4 h-4 flex items-center justify-center inline-flex"></i>
                Click History ({clickHistory.length})
              </button>
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'products' && (
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-6">Available Products</h2>
                {productsLoading ? (
                  <div className="text-center py-12">
                    <i className="ri-loader-4-line animate-spin text-4xl text-blue-600 mb-4 w-16 h-16 flex items-center justify-center mx-auto"></i>
                    <p className="text-gray-600">Loading products...</p>
                  </div>
                ) : products.length === 0 ? (
                  <div className="text-center py-12">
                    <i className="ri-shopping-bag-line text-6xl text-gray-300 mb-4 w-24 h-24 flex items-center justify-center mx-auto"></i>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No products available</h3>
                    <p className="text-gray-600">Check back later for new products!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {products.map((product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'history' && (
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-6">Your Click History</h2>
                {clickHistory.length === 0 ? (
                  <div className="text-center py-12">
                    <i className="ri-history-line text-6xl text-gray-300 mb-4 w-24 h-24 flex items-center justify-center mx-auto"></i>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No clicks yet</h3>
                    <p className="text-gray-600">Start browsing products to see your activity here!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {clickHistory.map((click) => (
                      <div key={click.id} className="bg-gray-50 rounded-lg p-4 flex items-center justify-between">
                        <div>
                          <h3 className="font-medium text-gray-900">{click.productName}</h3>
                          <p className="text-sm text-gray-500">
                            Clicked on {click.clickedAt.toLocaleDateString()} at{' '}
                            {click.clickedAt.toLocaleTimeString()}
                          </p>
                        </div>
                        <div className="flex items-center text-green-600">
                          <i className="ri-external-link-line w-4 h-4 flex items-center justify-center mr-1"></i>
                          <span className="text-sm font-medium">Visited</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
