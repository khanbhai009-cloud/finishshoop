
'use client';

import { useState, memo } from 'react';
import { useAuthState } from 'react-firebase-hooks/auth';
import { doc, updateDoc, increment, addDoc, collection } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { Product } from '../lib/types';
import LazyImage from './LazyImage';

interface ProductCardProps {
  product: Product;
}

const ProductCard = memo(function ProductCard({ product }: ProductCardProps) {
  const [user] = useAuthState(auth);
  const [isLoading, setIsLoading] = useState(false);

  const handleAffiliateClick = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      // Track click
      await addDoc(collection(db, 'clickTracking'), {
        productId: product.id,
        userId: user.uid,
        userEmail: user.email,
        clickedAt: new Date(),
        productName: product.name
      });

      // Increment product clicks
      await updateDoc(doc(db, 'products', product.id), {
        clicks: increment(1)
      });

      // Open affiliate link
      window.open(product.affiliateLink, '_blank');
    } catch (error) {
      console.error('Error tracking click:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const discountedPrice = product.price - (product.price * product.discount / 100);

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 will-change-transform">
      <div className="relative">
        <LazyImage 
          src={product.imageUrl} 
          alt={product.name}
          className="w-full h-64 object-cover object-top"
        />
        {product.tag && (
          <div className={`absolute top-2 left-2 px-2 py-1 rounded-full text-xs font-medium ${
            product.tag === 'New' ? 'bg-green-100 text-green-800' :
            product.tag === 'Best Seller' ? 'bg-blue-100 text-blue-800' :
            'bg-red-100 text-red-800'
          }`}>
            {product.tag}
          </div>
        )}
        {product.discount > 0 && (
          <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium">
            -{product.discount}%
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">{product.name}</h3>
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{product.description}</p>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            {product.discount > 0 ? (
              <>
                <span className="text-lg font-bold text-green-600">${discountedPrice.toFixed(2)}</span>
                <span className="text-sm text-gray-500 line-through">${product.price.toFixed(2)}</span>
              </>
            ) : (
              <span className="text-lg font-bold text-gray-900">${product.price.toFixed(2)}</span>
            )}
          </div>
          <div className="flex items-center space-x-1 text-gray-500 text-xs">
            <i className="ri-eye-line w-4 h-4 flex items-center justify-center"></i>
            <span>{product.clicks || 0}</span>
          </div>
        </div>

        <button
          onClick={handleAffiliateClick}
          disabled={!user || isLoading}
          className={`w-full py-2 px-4 rounded-md font-medium text-sm whitespace-nowrap cursor-pointer transition-colors ${
            user 
              ? 'bg-blue-600 text-white hover:bg-blue-700' 
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
        >
          {isLoading ? (
            <span className="flex items-center justify-center">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              Loading...
            </span>
          ) : user ? (
            'Shop Now'
          ) : (
            'Login to Shop'
          )}
        </button>
      </div>
    </div>
  );
});

export default ProductCard;
