
export interface Product {
  id: string;
  name: string;
  imageUrl: string;
  price: number;
  discount: number;
  description: string;
  affiliateLink: string;
  tag: 'New' | 'Best Seller' | 'Sale' | '';
  createdAt: Date;
  clicks: number;
}

export interface User {
  uid: string;
  email: string;
  displayName?: string;
  createdAt: Date;
}

export interface ClickTracking {
  id: string;
  productId: string;
  userId: string;
  userEmail: string;
  clickedAt: Date;
  productName: string;
}
